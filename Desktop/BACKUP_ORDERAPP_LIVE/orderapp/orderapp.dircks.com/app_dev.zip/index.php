<?php
echo "Test";
$output = exec('composer update');
echo "<pre>$output</pre>";
echo "test2";
?>