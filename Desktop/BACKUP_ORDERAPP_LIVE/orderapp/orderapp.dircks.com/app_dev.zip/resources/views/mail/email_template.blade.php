<!-- resources/views/email_template.blade.php -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quatation Dircks</title>
   
</head>

<body>
    <p>Hello,</p>
    <p>Customer Name: {{ $name }}</p>
    <p>Routes : "{{$pickupAddress}}" <b> To </b> "{{$deliveryAddress}}"</p>

    <p> Vehicle Details :
    <table style="border: 1px solid #000; border-collapse: collapse;">
        @foreach($vehicles as $vehicle)
        <tr>
            <td style="border: 1px solid; padding: 5px 10px;">{{$vehicle['year']}}</td>
            <td style="border: 1px solid; padding: 5px 10px;">{{$vehicle['make']}}</td>
            <td style="border: 1px solid; padding: 5px 10px;">{{$vehicle['model']}}</td>
            <td style="border: 1px solid; padding: 5px 10px;">{{$vehicle['type']}}</td>
        </tr>
        @endforeach
    </table>
    </p>
    <p>Estimated Carrier Price: ${{$final_value}}</p>
    <p>Thank you for choosing Dircks Auto Shipping.</p>
    <p>Team Dircks</p>
</body>

</html>