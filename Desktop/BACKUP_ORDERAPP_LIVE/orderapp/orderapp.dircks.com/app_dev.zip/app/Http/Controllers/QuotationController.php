<?php

namespace App\Http\Controllers;

use App\Quotation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Mail;
use App\Mail\MyEmail;

class QuotationController extends Controller
{

    public $suberDispacheObj;
    public $markupList;
    public function __construct()
    {
        $this->suberDispacheObj =  new SuperDispatchController;
        $this->markupList =  Config::get('app.QUOTATION_MARKUP');;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($type)
    {
        return view('quotation',compact('type'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $postFiled = (object)[];
        $postFiledStore = (object)[];
        $type = $request->type1;
        $pickupAddress = $request->pickup_address;
        $deliveryAddress = $request->delivery_address;
        /* Order Number */
        $postFiled->pickup_address = $pickupAddress;
        $postFiled->delivery_address   = $deliveryAddress;


        $postFiledStore->pickup_address = $pickupAddress;
        $postFiledStore->delivery_address   = $deliveryAddress;
        $postFiledStore->customer_name   = $request->customer_name;
        $postFiledStore->customer_email_id   = $request->customer_email_id;
        $postFiledStore->sales_person_name   = $request->sales_person_name;

        $vehicles = [];
        $vehicleLength = $request->vehicle_length;
        for ($i = 1; $i <= $vehicleLength; $i++) {
            $vehicleSignleArray = array(
                'vin' => $request['vin' . $i],
                'year' => $request['year' . $i],
                'make' => $request['make' . $i],
                'model' => $request['model' . $i],
                'tariff' => $request['tariff' . $i],
                'type' => $request['type' . $i],
                'is_inoperable' => (($request['indp' . $i]) ?  true :  false)
            );
            array_push($vehicles, $vehicleSignleArray);
        }
        $postFiledStore->vehicle = $vehicles;

        $postUrl = 'v1/public/prices/price_prediction/'.$type;
        $getQuotation = $this->suberDispacheObj->getApiCall($postUrl, $postFiled);
        if ($getQuotation['status'] == 'success') {
            if(($request->quote_type)!='' && $request->quote_type!=null){
                $getQuoteValue = $getQuotation['data']['object'];
                $markupListFind = (array)json_decode($this->markupList);
                $selectedMarkupValue =$markupListFind[$request->quote_type];
                $finalValue =  (($getQuoteValue*$selectedMarkupValue) / 100) + $getQuoteValue;
                $postFiledStore->quote_value = $getQuoteValue;
                $postFiledStore->quote_type = $request->quote_type;
                $postFiledStore->final_value = $finalValue;
            }
            Quotation::create([
                'payload' => json_encode($postFiledStore),
            ]);
            /* Mail */
            $name = ($request->customer_name) ? $request->customer_name : 'Dear'; // You can pass the necessary data to the Mailable constructor
             if($request->customer_email_id){
                //Mail::to($request->customer_email_id)->send(new MyEmail($name,$finalValue));
                //Mail::to($request->customer_email_id)->send(new MyEmail($name, $finalValue, $vehicles, $pickupAddress, $deliveryAddress));
             }
            /* Mail */
            
            return response()->json(array('status' => true, 'quote_value' => $finalValue));
        } else {
            return response()->json(array('status' => false, 'error' => 'Something went wrong.'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function show(Quotation $quotation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function edit(Quotation $quotation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Quotation $quotation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function destroy(Quotation $quotation)
    {
        //
    }
}
