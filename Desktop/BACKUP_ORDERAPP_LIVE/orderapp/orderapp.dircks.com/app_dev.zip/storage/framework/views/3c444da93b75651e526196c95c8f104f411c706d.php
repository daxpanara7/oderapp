<footer class="mt-5 col-12 ">
    
</footer><?php /**PATH /home/dreamzon/public_html/dircks.xelentor.com/resources/views/partials/footer.blade.php ENDPATH**/ ?>