<?php

namespace App\Http\Controllers;

use App\Quotation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;


class QuotationController extends Controller
{

    public $suberDispacheObj;
    public $markupList;
    public function __construct()
    {
        $this->suberDispacheObj =  new SuperDispatchController;
        $this->markupList =  Config::get('app.QUOTATION_MARKUP');;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($type)
    {
        return view('quotation',compact('type'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $postFiled = (object)[];
        /* Order Number */
        $postFiled->pickup_address = 'NYC, NY';
        $postFiled->delivery_address   = 'Las Vegas, NV';
        $postUrl = 'v1/public/prices/price_prediction/sedan';
        $getQuotation = $this->suberDispacheObj->getApiCall($postUrl, $postFiled);
        //https://api.shipper.superdispatch.com/v1/public/
        if ($getQuotation['status'] == 'success') {
            if(($request->quote_type)!='' && $request->quote_type!=null){
                $getQuoteValue = $getQuotation['data']['object'];
                $markupListFind = (array)json_decode($this->markupList);
                $selectedMarkupValue =$markupListFind[$request->quote_type];
                $finalValue =  (($getQuoteValue*$selectedMarkupValue) / 100) + $getQuoteValue;
            }
            return response()->json(array('status' => true, 'quote_value' => $finalValue));
        } else {
            return response()->json(array('status' => false, 'error' => 'Something went wrong.'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function show(Quotation $quotation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function edit(Quotation $quotation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Quotation $quotation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Quotation  $quotation
     * @return \Illuminate\Http\Response
     */
    public function destroy(Quotation $quotation)
    {
        //
    }
}
