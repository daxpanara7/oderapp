<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

class SuperDispatchController extends Controller
{
    public $superDispatchClientId;
    public $superDispatchClientSecret;
    public $base64Token;
    public $baseUrl;
    public function __construct()
    {
        $this->superDispatchClientId = Config::get('app.SUPER_DISPATCH_CLIENT_ID');
        $this->superDispatchClientSecret =  Config::get('app.SUPER_DISPATCH_CLIENT_SECRET');
        $this->base64Token =  base64_encode($this->superDispatchClientId . ":" .  $this->superDispatchClientSecret);
        $this->baseUrl = 'https://api.shipper.superdispatch.com/';
    }

    public function authToken()
    {
        $postUrl = 'oauth/token?grant_type=client_credentials';
        $apiUrl = $this->baseUrl . $postUrl;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Basic ' . $this->base64Token
            ),
        ));
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($httpCode >= 200 && $httpCode < 300) {
            // Successful response
            $responseData = json_decode($response, true);
        } else {
            // Error response
            $responseData = json_decode($response, true);
        }
        return $responseData;
    }

    public function getApiCall($postUrl, $postFiled)
    {
        $apiUrl = $this->baseUrl . $postUrl;
        if (!empty($postFiled)) {
            $QueryParameters = '?';
            $i = 1;
            foreach ($postFiled as $key => $value) {
                $QueryParameters .= (($i == 1) ? '' : '&') . $key . '=' . urlencode($value);
                $i++;
            }
            $apiUrl .= $QueryParameters;
        }
        $tokenObj = $this->authToken();
        $token = $tokenObj['access_token'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $apiUrl,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer '.$token
          ),
        ));
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        if ($httpCode >= 200 && $httpCode < 300) {
            // Successful response
            $responseData = json_decode($response, true);
        } else {
            // Error response
            $responseData = json_decode($response, true);
        }
        return $responseData;
    }

    public function postApiCallArray($postUrl, $postFiled)
    {
        $tokenObj = $this->authToken();
        $token = $tokenObj['access_token'];
        $apiUrl = $this->baseUrl . $postUrl;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $postFiled,
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $token
            ),
        ));
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($httpCode >= 200 && $httpCode < 300) {
            // Successful response
            $responseData = json_decode($response, true);
        } else {
            // Error response
            $responseData = json_decode($response, true);
        }
        return $responseData;
    }

    public function postApiCallJson($postUrl, $postFiled)
    {
        $tokenObj = $this->authToken();
        $token = $tokenObj['access_token'];
        $apiUrl = $this->baseUrl . $postUrl;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode((array)$postFiled),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token
            ),
        ));
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($httpCode >= 200 && $httpCode < 300) {
            // Successful response
            $responseData = json_decode($response, true);
        } else {
            // Error response
            $responseData = json_decode($response, true);
        }
        return $responseData;
    }
}
