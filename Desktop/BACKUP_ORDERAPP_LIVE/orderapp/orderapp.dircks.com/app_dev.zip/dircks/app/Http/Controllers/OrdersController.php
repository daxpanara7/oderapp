<?php

namespace App\Http\Controllers;

use App\orders;
use Illuminate\Http\Request;
use App\Http\Controllers\SuperDispatchController;

class OrdersController extends Controller
{
    public $suberDispacheObj;
    public function __construct()
    {
        $this->suberDispacheObj =  new SuperDispatchController;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    }

    /**
     * Show the form for creating a new order.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $postUrl = 'v1/public/carriers/approved';
        $postFiled = (object)[];
        $postFiled->size = 500;
        $postFiled->page = 0;
        $carrierData = $this->suberDispacheObj->getApiCall($postUrl, $postFiled);
        $carrierData = $carrierData['data']['objects'];
        return view('order', compact('carrierData'));
    }

    /**
     * Store a newly created order to database as well as super dispatch platform.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $vehicleLength = $request->vehicle_length;
        $orderNumber = $request->order_number;
        $trasnsportType = $request->trasnsport_type;

        $customerName = $request->customer_name;
        $customerVenueBusinessType = $request->customer_venue_business_type;
        $customerAddress = $request->customer_address;
        $customerState = $request->customer_state;
        $customerCity = $request->customer_city;
        $customerZipcode = $request->customer_zip_code;
        $customerPhoneNumber = $request->customer_phone_number;
        $customerBillingEmail = $request->customer_billing_email;

        $pickupBusinessName = $request->pickup_business_name;
        $pickupVenueBusinessType = $request->pickup_venue_business_type;
        $pickupBusinessAddress = $request->pickup_business_address;
        $pickupBusinessState = $request->pickup_business_state;
        $pickupBusinessCity = $request->pickup_business_city;
        $pickupBusinessZipCode = $request->pickup_business_zip_code;
        $pickupContactName = $request->pickup_contact_name;
        $pickupContactTitle = $request->pickup_contact_title;
        $pickupContactPhoneNumber = $request->pickup_contact_phone_number;
        $pickupContactMobileNumber = $request->pickup_contact_mobile_number;
        $pickupContactEmailId = $request->pickup_contact_email_id;
        $pickupDateType = $request->pickup_date_type;
        $carrierPickupDate = $request->carrier_pickup_date; // Delivery note
        $carrierPickupNotes = $request->carrier_pickup_notes;


        $deliveryVenueBusinessName = $request->delivery_venue_business_name;
        $deliveryVenueBusinessType = $request->delivery_venue_business_type;
        $deliveryBusinessAddress = $request->delivery_business_address;
        $deliveryBusinessState = $request->delivery_business_state;
        $deliveryBusinessCity = $request->delivery_business_city;
        $deliveryBusinessZipCode = $request->delivery_business_zip_code;
        $deliveryContactName = $request->delivery_contact_name;
        $deliveryContactTitle = $request->delivery_contact_title;
        $deliveryContactPhoneNumber = $request->delivery_contact_phone_number;
        $deliveryContactMobileNumber = $request->delivery_contact_mobile_number;
        $deliveryContactEmailId = $request->delivery_contact_email_id;

        $totalTarriff = $request->total_tarriff;
        $paymentNotes = $request->payment_notes;



        $trasnsportType = $request->trasnsport_type;


        $postUrl = 'v1/public/orders';
        $postFiled = (object)[];
        /* Order Number */
        $postFiled->number = $orderNumber;

        /* Cusotmer Payment and notes */
        $customerPayment = (object)[];
        $customerPayment->tariff = ($totalTarriff) ?  $totalTarriff : '';
        $customerPayment->amount =  ($totalTarriff) ?  $totalTarriff : '';
        $customerPayment->notes = ($paymentNotes) ?  $paymentNotes : '';
        $postFiled->customer_payment = $customerPayment;


        /* Pickup */
        $pickupVenue = (object)[];
        $pickupVenue->address = ($pickupBusinessAddress) ? $pickupBusinessAddress : '';
        $pickupVenue->city = ($pickupBusinessCity) ?  $pickupBusinessCity :  '';
        $pickupVenue->state = ($pickupBusinessState) ?  $pickupBusinessState : '';
        $pickupVenue->zip = ($pickupBusinessZipCode) ?  $pickupBusinessZipCode :  '';
        $pickupVenue->name = ($pickupBusinessName) ?  $pickupBusinessName  : '';
        $pickupVenue->business_type = ($pickupVenueBusinessType) ? $pickupVenueBusinessType : '';
        $pickupVenue->contact_name = ($pickupContactName) ?  $pickupContactName :  '';
        $pickupVenue->contact_title = ($pickupContactTitle) ?  $pickupContactTitle : '';
        $pickupVenue->contact_email = ($pickupContactEmailId) ?  $pickupContactEmailId : '';
        $pickupVenue->contact_phone = ($pickupContactPhoneNumber) ? $pickupContactPhoneNumber : '';
        $pickupVenue->contact_mobile_phone = ($pickupContactMobileNumber) ? $pickupContactMobileNumber : '';

        $pickup = (object)[];
        //$pickup->scheduled_at = ($carrierPickupDate) ?  $carrierPickupDate :  '';
        //$pickup->scheduled_ends_at = '';
        //$pickup->date_type = ($pickupDateType) ?  $pickupDateType : '';
        $pickup->notes = ($carrierPickupNotes) ? $carrierPickupNotes : '';
        $pickup->venue = $pickupVenue;
        $postFiled->pickup = $pickup;

        /* Pickup */
        $delivery = (object)[];
        $deliveryVenue = (object)[];
        $deliveryVenue->address = ($deliveryBusinessAddress) ? $deliveryBusinessAddress : '';
        $deliveryVenue->city = ($deliveryBusinessCity) ? $deliveryBusinessCity : '';
        $deliveryVenue->state = ($deliveryBusinessState) ?  $deliveryBusinessState : '';
        $deliveryVenue->zip = ($deliveryBusinessZipCode) ?  $deliveryBusinessZipCode : '';
        $deliveryVenue->name = ($deliveryVenueBusinessName) ?  $deliveryVenueBusinessName  : '';
        $deliveryVenue->business_type = ($deliveryVenueBusinessType) ? $deliveryVenueBusinessType : '';
        $deliveryVenue->contact_name = ($deliveryContactName) ?  $deliveryContactName : '';
        $deliveryVenue->contact_title = ($deliveryContactTitle) ? $deliveryContactTitle : '';
        $deliveryVenue->contact_email = ($deliveryContactEmailId) ? $deliveryContactEmailId : '';
        $deliveryVenue->contact_phone = ($deliveryContactPhoneNumber) ? $deliveryContactPhoneNumber : '';
        $deliveryVenue->contact_mobile_phone = ($deliveryContactMobileNumber) ?  $deliveryContactMobileNumber : '';
        $delivery->notes = ''; // deleivery note data bind pending.
        $delivery->venue = $deliveryVenue;
        $postFiled->delivery = $delivery;

        /* Customer information */
        $customerInfo = (object)[];
        $customerInfo->address = ($customerAddress) ?  $customerAddress : '';
        $customerInfo->city = ($customerCity) ? $customerCity : '';
        $customerInfo->state = ($customerState) ?  $customerState : '';
        $customerInfo->zip = ($customerZipcode) ?  $customerZipcode : '';
        $customerInfo->name = ($customerName) ?  $customerName : '';
        $customerInfo->business_type = ($customerVenueBusinessType) ?  $customerVenueBusinessType : '';
        $customerInfo->contact_email = ($customerBillingEmail) ? $customerBillingEmail : ''; // replicated 
        $customerInfo->email = ($customerBillingEmail) ? $customerBillingEmail : '';
        $customerInfo->contact_phone = ($customerPhoneNumber) ?  $customerPhoneNumber : '';
        $postFiled->customer = $customerInfo;
        $postFiled->transport_type = ($trasnsportType) ?  $trasnsportType : '';


        /* vehicle information */
        $vehicles = [];
        for ($i = 1; $i <= $vehicleLength; $i++) {
            $vehicleSignleArray = array(
                'vin' => $request['vin' . $i],
                'year' => $request['year' . $i],
                'make' => $request['make' . $i],
                'model' => $request['model' . $i],
                'tariff' => $request['tariff' . $i],
                'type' => $request['type' . $i],
                'is_inoperable' => (($request['indp' . $i]) ?  true :  false)
            );
            array_push($vehicles, $vehicleSignleArray);
        }

        $postFiled->vehicles = $vehicles;
        /* Create order API Call */
        $createOrder = $this->suberDispacheObj->postApiCallJson($postUrl, $postFiled);
        if ($createOrder['status'] == 'success') {
            // Orders::create([
            //     'payload' => json_encode($postFiled),
            //     'guid' => 'value2',
            //     // Add other columns as needed
            // ]);
            return response()->json(array('status' => true, 'guid' => $createOrder['data']));
        } else {
            return response()->json(array('status' => false, 'error' => 'Something went wrong.'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function show(orders $orders)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function edit(orders $orders)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, orders $orders)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function destroy(orders $orders)
    {
        //
    }
}
