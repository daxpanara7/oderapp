@extends('layouts.app')
@section('content')
<style>
    .ml-force {
        margin-left: -1% !important;
    }

    .mt-force {
        margin-top: -1% !important;
    }

    .mr-force {
        margin-right: -27px;
    }

    .file-upload {
        display: none;
    }

    .upload-icon {
        font-size: 24px;
    }

    label.force-align-right {
        right: 0.8rem;
        display: inline;
        position: absolute;
        top: 0.7rem;
        font-size: 14px;
    }
</style>
<div class="row">
    <div class="col-md-12  offset-md-12">

        <form method="POST" name="order_create" id="order_create">
            @csrf
            <input type="hidden" name="vehicle_length" id="vehicle_length">
            <!-- Order Details -->
            <label class="mt-3 mb-0 ml-force font-weight-bold">Order Details</label>
            <div class="row bg-light border rounded">
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="order_number" class="mb-0 mt-2">Order Number*</label>
                    <input type="text" class="form-control" id="order_number" name="order_number" placeholder="Order Number">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="trasnsport_type" class="mb-0 mt-2">Transport Type</label>
                    <select class="form-control" id="trasnsport_type" name="trasnsport_type">
                        <option value="OPEN">Open</option>
                        <option value="ENCLOSED">Enclosed</option>
                        <option value="DRIVEAWAY">Driveaway</option>
                    </select>
                </div>
            </div>

            <!-- Vehicles Details -->
            <label class="mt-3 mb-0 ml-0 pl-0 ml-force font-weight-bold">Vehicles</label>
            <div class="row bg-light border rounded">
                <div id="vehicle_block" class="col-md-12  offset-md-12 row">

                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12 text-right mt-0">
                    <a class="form-group btn-success p-2 rounded" role="button" onclick="addVehicle()">Add Vehicle</a>
                </div>
            </div>

            <!-- Customer Information -->
            <label class="mt-3 mb-0 ml-0 pl-0 ml-force font-weight-bold">Customer Information</label>
            <div class="row bg-light border rounded">
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="customer_name" class="mb-0 mt-2">Customer Name</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="customer_venue_business_type" class="mb-0 mt-2">Type</label>
                    <select type="text" class="form-control" id="customer_venue_business_type" name="customer_venue_business_type">
                        <option value="BUSINESS">Business</option>
                        <option value="DEALER">Dealer</option>
                        <option value="PRIVATE">Private</option>
                        <option value="AUCTION">Auction</option>
                        <option value="REPO_YARD">Repo Yard</option>
                        <option value="PORT">Port</option>
                    </select>
                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12">
                    <label for="customer_address" class="mb-0 mt-2">Address</label>
                    <textarea class="form-control" id="customer_address" name="customer_address"></textarea>
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="customer_state" class="mb-0 mt-2">State</label>
                    <input type="text" class="form-control" id="customer_state" name="customer_state">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="customer_city" class="mb-0 mt-2">City</label>
                    <input type="text" class="form-control" id="customer_city" name="customer_city">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="customer_zip_code" class="mb-0 mt-2">Zip Code</label>
                    <input type="text" class="form-control" id="customer_zip_code" name="customer_zip_code">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="customer_phone_number" class="mb-0 mt-2">Phone Number</label>
                    <input type="text" class="form-control" id="customer_phone_number" name="customer_phone_number" onkeyup="validateNumericInput('customer_phone_number')">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="customer_billing_email" class="mb-0 mt-2">Billing Email</label>
                    <input type="text" class="form-control" id="customer_billing_email" name="customer_billing_email">
                </div>
            </div>

            <!-- Pick-up Information -->
            <label class="mt-3 mb-0 ml-0 pl-0 ml-force font-weight-bold">Pick-up Information</label>
            <div class="row bg-light border rounded">
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="pickup_business_name" class="mb-0 mt-2">Business Name</label>
                    <label class="force-align-right copy-for-pickup"><i class="fa fa-copy"></i> Same as customer</label>
                    <input type="text" class="form-control" id="pickup_business_name" name="pickup_business_name">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="pickup_venue_business_type" class="mb-0 mt-2">Type</label>
                    <select type="text" class="form-control" id="pickup_venue_business_type" name="pickup_venue_business_type">
                        <option value="BUSINESS">Business</option>
                        <option value="DEALER">Dealer</option>
                        <option value="PRIVATE">Private</option>
                        <option value="AUCTION">Auction</option>
                        <option value="REPO_YARD">Repo Yard</option>
                        <option value="PORT">Port</option>
                    </select>
                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12">
                    <label for="pickup_business_address" class="mb-0 mt-2">Address</label>
                    <textarea class="form-control" id="pickup_business_address" name="pickup_business_address"></textarea>
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="pickup_business_state" class="mb-0 mt-2">State</label>
                    <input type="text" class="form-control" id="pickup_business_state" name="pickup_business_state">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="pickup_business_zip_code" class="mb-0 mt-2">City</label>
                    <input type="text" class="form-control" id="pickup_business_city" name="pickup_business_city">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="business_zip_code" class="mb-0 mt-2">Zip Code</label>
                    <input type="text" class="form-control" id="pickup_business_zip_code" name="pickup_business_zip_code">
                </div>

                <!-- -- Contact Information -->
                <div class="form-group col-md-12 col-lg-12 col-sa-12 mb-0">
                    <hr class="hr mb-0 mt-0">
                    <label class="mb-0 mt-0 mt-force font-weight-bold">Contact Information</label>
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="contact_name" class="mb-0 mt-2">Contact Name</label>
                    <input type="text" class="form-control" id="pickup_contact_name" name="pickup_contact_name">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="contact_title" class="mb-0 mt-2">Title</label>
                    <input type="text" class="form-control" id="pickup_contact_title" name="pickup_contact_title">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="contact_phone_number" class="mb-0 mt-2">Phone Number</label>
                    <input type="text" class="form-control" id="pickup_contact_phone_number" name="pickup_contact_phone_number" onkeyup="validateNumericInput('pickup_contact_phone_number')">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="contact_mobile_number" class="mb-0 mt-2">Mobile Number</label>
                    <input type="text" class="form-control" id="pickup_contact_mobile_number" name="pickup_contact_mobile_number" onkeyup="validateNumericInput('pickup_contact_mobile_number')">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="contact_email_id" class="mb-0 mt-2">Email Id</label>
                    <input type="text" class="form-control" id="pickup_contact_email_id" name="pickup_contact_email_id">
                </div>
                <!-- -- Date & Notes -->
                <div class="form-group col-md-12 col-lg-12 col-sa-12 mb-0">
                    <hr class="hr mb-0 mt-0">
                    <label class="mb-0 mt-0 mt-force font-weight-bold">Date & Notes</label>
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="date_type" class="mb-0 mt-2">Date type</label>
                    <select class="form-control" id="pickup_date_type" name="pickup_date_type">
                        <option value="estimated">Estimated</option>
                        <option value="exact">Exact</option>
                        <option value="not_earlier_than">No Earlier than</option>
                        <option value="not_later_than">No Later than</option>
                    </select>
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="carrier_pickup_date" class="mb-0 mt-2">Carrier Pickup Date</label>
                    <input type="text" class="form-control" id="carrier_pickup_date" name="carrier_pickup_date">
                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12">
                    <label for="carrier_pickup_notes" class="mb-0 mt-2">Notes <i class="fa fa-info-circle"></i></label>
                    <textarea class="form-control" id="carrier_pickup_notes" name="carrier_pickup_notes"></textarea>
                </div>
            </div>

            <!-- Delivery Information -->
            <label class="mt-3 mb-0 ml-0 pl-0 ml-force font-weight-bold">Delivery Information</label>
            <div class="row bg-light border rounded">
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="delivery_venue_business_name" class="mb-0 mt-2">Business Name</label>
                    <label class="force-align-right copy-for-delivery"><i class="fa fa-copy"></i> Same as customer</label>
                    <input type="text" class="form-control" id="delivery_venue_business_name" name="delivery_venue_business_name">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="delivery_venue_business_type" class="mb-0 mt-2">Type</label>
                    <select type="text" class="form-control" id="delivery_venue_business_type" name="delivery_venue_business_type">
                        <option value="BUSINESS">Business</option>
                        <option value="DEALER">Dealer/option>
                        <option value="PRIVATE">Private</option>
                        <option value="AUCTION">Auction</option>
                        <option value="REPO_YARD">Repo Yard</option>
                        <option value="PORT">Port</option>
                    </select>
                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12">
                    <label for="delivery_business_address" class="mb-0 mt-2">Address</label>
                    <textarea class="form-control" id="delivery_business_address" name="delivery_business_address"></textarea>
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="delivery_business_state" class="mb-0 mt-2">State</label>
                    <input type="text" class="form-control" id="delivery_business_state" name="delivery_business_state">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="delivery_business_city" class="mb-0 mt-2">City</label>
                    <input type="text" class="form-control" id="delivery_business_city" name="delivery_business_city">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="delivery_business_zip_code" class="mb-0 mt-2">Zip Code</label>
                    <input type="text" class="form-control" id="delivery_business_zip_code" name="delivery_business_zip_code">
                </div>
                <!-- -- Contact Information -->
                <div class="form-group col-md-12 col-lg-12 col-sa-12 mb-0">
                    <hr class="hr mb-0 mt-0">
                    <label class="mb-0 mt-0 mt-force font-weight-bold">Contact Information</label>
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="delivery_contact_name" class="mb-0 mt-2">Contact Name</label>
                    <input type="text" class="form-control" id="delivery_contact_name" name="delivery_contact_name">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="contact_title" class="mb-0 mt-2">Title</label>
                    <input type="text" class="form-control" id="delivery_contact_title" name="delivery_contact_title">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="delivery_contact_phone_number" class="mb-0 mt-2">Phone Number</label>
                    <input type="text" class="form-control" id="delivery_contact_phone_number" name="delivery_contact_phone_number" onkeyup="validateNumericInput('delivery_contact_phone_number')">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="delivery_contact_mobile_number" class="mb-0 mt-2">Mobile Number</label>
                    <input type="text" class="form-control" id="delivery_contact_mobile_number" name="delivery_contact_mobile_number" onkeyup="validateNumericInput('delivery_contact_mobile_number')">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="delivery_contact_email_id" class="mb-0 mt-2">Email Id</label>
                    <input type="text" class="form-control" id="delivery_contact_email_id" name="delivery_contact_email_id">
                </div>
                <!-- Date & Notes -->
                <div class="form-group col-md-12 col-lg-12 col-sa-12 mb-0">
                    <hr class="hr mb-0 mt-0">
                    <label class="mb-0 mt-0 mt-force font-weight-bold">Date & Notes</label>
                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12">
                    <label for="carrier_pickup_date" class="mb-0 mt-2">Notes <i class="fa fa-info-circle"></i></label>
                    <textarea class="form-control" id="carrier_pickup_date" name="carrier_pickup_date"></textarea>
                </div>
            </div>

            <!-- Customer Payment -->
            <label class="mt-3 mb-0 ml-0 pl-0 ml-force font-weight-bold">Customer Payment</label>
            <div class="row bg-light border rounded">
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="total_tarriff" class="mb-0 mt-2">Total Customer Price</label>
                    <div class="input-group">
                        <span class="input-group-addon border-top border-bottom border-left pl-2 pr-2 pt-1 rounded-left">$</span>
                        <input type="text" class="form-control" id="total_tarriff" name="total_tarriff" onkeyup="validateNumericInput('total_tarriff')">
                    </div>
                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12">
                    <label for="payment_notes" class="mb-0 mt-2">Notes</label>
                    <textarea class="form-control" id="payment_notes" name="payment_notes"></textarea>
                </div>
            </div>

            <!-- DisPatcher & Salseperson -->
            <label class="mt-3 mb-0 ml-0 pl-0 ml-force font-weight-bold">Dispatcher & Salseperson</label>
            <div class="row bg-light border rounded">
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="dispatcher" class="mb-0 mt-2">Dispatcher</label>
                    <select class="form-control" id="dispatcher" name="dispatcher">
                        @foreach($carrierData as $key=>$value)
                        <option value="<?= $value['guid'] ?>"><?= $value['name'] ?></option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="d_business_name" class="mb-0 mt-2">Sales Person</label>
                    <select class="form-control" id="d_business_name" name="d_business_name">
                        <option>None</option>
                        <option>etc</option>
                    </select>
                </div>
            </div>

            <div class="form-group mt-5 col-md-12 col-lg-12 col-sm-12 text-right mt-0">
                <button type="submit" class="form-group btn-success p-2 rounded mr-force">Save</button>
            </div>

        </form>

    </div>
</div>
@endsection
@section('jsScript')
<script>
    var i = 0;
    jQuery(document).ready(function() {
        /* On page load add  first vehicle row*/
        addVehicle();
        $('.delete_row').addClass('d-none');
        /* delete vehicle row */
        jQuery(document).on('click', '.delete_row', function() {
            var rowId = $(this).data('row');
            $('.delete_row').addClass('d-none');
            var vehicleLength = jQuery('.vehicle-row-exist').length;
            if (vehicleLength == 1) {

                toastr.error('You can delete vehicle.');
                return false;
            }
            jQuery('.vehicleRow' + rowId).remove();
            if (vehicleLength != 1)
                $('.delete_' + (rowId - 1)).removeClass('d-none');
            $('#vehicle_length').val(jQuery('.vehicle-row-exist').length)
        });

        /* Form Submit with validation check */
        $("#order_create").submit(function(e) {
            e.preventDefault();
        }).validate({
            rules: {
                order_number: {
                    required: true,
                },
                pickup_contact_mobile_number: {
                    number: true
                },
                pickup_contact_name: {
                    number: true
                }
            },
            submitHandler: function(form) {
                $('.loading').show();
                $.ajax({
                    url: '{{route("orderCreate")}}',
                    method: 'POST',
                    data: $(form).serialize(),
                    success: function(response) {
                        if (response && response.status) {
                            $('.loading').hide();
                            toastr.success('Your order created. Page will redirect in 5 second');
                            setTimeout(() => {
                                window.location.reload();
                            }, 5000);
                        } else {
                            $('.loading').hide();
                            console.error("Property 'mode' is undefined in the response.");
                        }
                    },
                    error: function(xhr, status, error) {
                        $('.loading').hide();
                        console.error("AJAX request failed:", status, error);
                    }
                });
            },
        })

        //Pickup  carrier date initilized
        dateChange('carrier_pickup_date', 'range')

        /* Date type change */
        $('#pickup_date_type').change(function() {
            var value = $(this).val();
            if (value == 'estimated') {
                dateChange('carrier_pickup_date', 'range')
            } else {
                dateChange('carrier_pickup_date', 'single')
            }
        })

        /* Same as customer copy*/
        $('.copy-for-pickup, .copy-for-delivery').click(function() {
            var customerName = $('#customer_name').val();
            var customerBusinessType = $('#customer_venue_business_type').val();
            var customerAddress = $('#customer_address').val();
            var customerState = $('#customer_state').val();
            var customerCity = $('#customer_city').val();
            var customerZipCode = $('#customer_zip_code').val();
            if ($(this).attr("class") == 'force-align-right copy-for-pickup') {
                $('#pickup_business_name').val(customerName);
                $('#pickup_venue_business_type').val(customerBusinessType);
                $('#pickup_business_address').val(customerAddress);
                $('#pickup_business_state').val(customerState);
                $('#pickup_business_city').val(customerCity);
                $('#pickup_business_zip_code').val(customerZipCode);
            } else {
                $('#delivery_venue_business_name').val(customerName);
                $('#delivery_venue_business_type').val(customerBusinessType);
                $('#delivery_business_address').val(customerAddress);
                $('#delivery_business_state').val(customerState);
                $('#delivery_business_city').val(customerCity);
                $('#delivery_business_zip_code').val(customerZipCode);
            }
        });
    })

    /* Add vehicle row on add vehicle button click */
    function addVehicle() {
        var vehicleLength = jQuery('.vehicle-row-exist').length;
        if (vehicleLength > 4) {
            toastr.error('You can not add more than 5 vehicle');
            //alert("You can not add more than 5 vehicle");
            return false;
        }
        i = vehicleLength + 1;
        $('.delete_row').addClass('d-none');
        var html = '';
        html += '<div class="col-md-12  offset-md-12 row vehicleRow' + i + ' vehicle-row-exist">';
        // html += '    <div class="form-group col-md-1 col-lg-1 col-sm-12">';
        // html += '        <label for="image" class="mb-0 mt-2">Image</label>';
        // html += '        <label for="image' + i + '" class="mb-0 mt-2 upload-icon"><i class="fa fa-upload ml-2"></i></label>';
        // html += '        <input type="file" class="form-control file-upload" id="image' + i + '" name="image' + i + '" />';
        // html += '    </div>';
        html += '    <div class="form-group col-md-2 col-lg-2 col-sm-12">';
        html += '        <label for="vin' + i + '" class="mb-0 mt-2">VIN</label>';
        html += '        <input class="form-control" id="vin' + i + '" name="vin' + i + '" />';
        html += '    </div>';
        html += '    <div class="form-group col-md-1 col-lg-1 col-sm-12">';
        html += '        <label for="year' + i + '" class="mb-0 mt-2">Year</label>';
        html += '        <input class="form-control" id="year' + i + '" name="year' + i + '" />';
        html += '    </div>';
        html += '    <div class="form-group col-md-1 col-lg-1 col-sm-12">';
        html += '        <label for="make' + i + '" class="mb-0 mt-2">Make</label>';
        html += '        <input class="form-control" id="make' + i + '" name="make' + i + '" />';
        html += '    </div>';
        html += '    <div class="form-group col-md-1 col-lg-1 col-sm-12">';
        html += '        <label for="model' + i + '" class="mb-0 mt-2">Model</label>';
        html += '        <input class="form-control" id="model' + i + '" name="model' + i + '" />';
        html += '    </div>';
        html += '    <div class="form-group col-md-2 col-lg-2 col-sm-12">';
        html += '        <label for="type' + i + '" class="mb-0 mt-2">Type</label>';
        html += '        <select class="form-control" id="type' + i + '" name="type' + i + '" >';
        html += '           <option value="sedan">Sedan</option>';
        html += '           <option value="2_door_coupe">Coupe (2 Door)</option>';
        html += '           <option value="suv">SUV</option>';
        html += '           <option value="pickup">Pickup (2 Door)</option>';
        html += '           <option value="4_door_pickup">Pickup (4 Door)</option>';
        html += '           <option value="van">Van</option>';
        html += '           <option value="truck_daycab">Truck (daycab)</option>';
        html += '           <option value="truck_sleeper">Truck (with sleeper)</option>';
        html += '           <option value="motorcycle">Motorcycle</option>';
        html += '           <option value="boat">Boat</option>';
        html += '           <option value="rv">RV</option>';
        html += '           <option value="heavy_machinery">Heavy Machinery</option>';
        html += '           <option value="freight">Freight</option>';
        html += '           <option value="livestock">Livestock</option>';
        html += '           <option value="atv">ATV</option>';
        html += '           <option value="trailer_bumper_pull">Trailer (Bumper Pull)</option>';
        html += '           <option value="trailer_gooseneck">Trailer (Gooseneck)</option>';
        html += '           <option value="trailer_5th_wheel">Trailer (5th Wheel)</option>';
        html += '           <option value="other">Other</option>';
        html += '        </select>';
        html += '    </div>';
        html += '    <div class="form-group col-md-2 col-lg-2 col-sm-12">';
        html += '        <label for="tariff' + i + '" class="mb-0 mt-2">Tariff</label>';
        html += '        <input class="form-control" id="tariff' + i + '" name="tariff' + i + '" />';
        html += '    </div>';
        html += '    <div class="form-group col-md-1 col-lg-1 col-sm-12">';
        html += '        <label for="indp' + i + '" class="mb-0 mt-2">INDP</label>';
        html += '        <input type="checkbox" class="form-control" id="indp' + i + '" name="indp' + i + '" />';
        html += '    </div>';
        html += '    <div class="form-group col-md-1 col-lg-1 col-sm-12">';
        html += '        <label for="exampleFormControlTextarea1" class="mb-0 mt-2"></label>';
        html += '        <div class="form-group mt-3">';
        html += '            <a class="delete_' + i + ' delete_row" data-row="' + i + '" class="mb-0 mt-2"><i class="fa fa-trash"></i></a>';
        html += '        </div>';
        html += '    </div>';
        html += '</div>';
        jQuery('#vehicle_block').append(html);
        $('#vehicle_length').val(jQuery('.vehicle-row-exist').length)
    }

    /* Date Picker Script */
    function dateChange(id, type) {
        $('#' + id).val('');
        $('#' + id).datepicker('destroy'); // Destroy the current instance
        if (type == 'range') {
            var datePickerRangeOptions = {
                format: 'yyyy-mm-dd',
                autoclose: false,
                clearBtn: true,
                multidateSeparator: " to ",
                multidate: 2 // Allow selecting a range of dates
            };
            $('#' + id).datepicker(datePickerRangeOptions);
        } else {
            var datepickerOptions = {
                format: 'yyyy-mm-dd',
                autoclose: true,
                clearBtn: true,
                todayHighlight: true
            };
            $('#' + id).datepicker(datepickerOptions);
        }
    }

    /* Only number allowed */
    function validateNumericInput(elemId) {
        var inputValue = $('#' + elemId).val();
        var numericValue = inputValue.replace(/[^0-9]/g, '');
        $('#' + elemId).val(numericValue);
    }
</script>
@stop