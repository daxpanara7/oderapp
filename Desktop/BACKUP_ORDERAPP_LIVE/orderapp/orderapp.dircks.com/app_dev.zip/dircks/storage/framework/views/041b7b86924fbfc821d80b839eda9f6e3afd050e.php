<footer class="mt-5 col-12 ">
    <div class="container">
        <p>&copy; 2023 Dricks. All rights reserved.</p>
        <!-- Add your footer content here -->
    </div>
</footer><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dircks/resources/views/partials/footer.blade.php ENDPATH**/ ?>