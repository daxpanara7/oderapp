<header>
   <!--  <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Dricks</a>
        
    </nav> -->
</header><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dircks/resources/views/partials/header.blade.php ENDPATH**/ ?>