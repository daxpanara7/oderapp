@extends('layouts.app')
@section('content')
<style>
    .ml-force {
        margin-left: -1% !important;
    }

    .mt-force {
        margin-top: -1% !important;
    }

    .mr-force {
        margin-right: -27px;
    }

    .pt-4_5 {
        padding-top: 2.4rem !important;
    }
</style>
<div class="row">
    <div class="col-md-12  offset-md-12">

        <form name="getQuotation" id="getQuotation" method="POST">
            @csrf
            <input type="hidden" name="quote_type" value="{{$type}}">
            <!-- DisPatcher & Salseperson -->
            <label class="mt-3 mb-0 ml-0 pl-0 ml-force font-weight-bold">Shipping Details</label>
            <div class="row bg-light border rounded">
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="customer_name" class="mb-0 mt-2">Customer Name</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="customer_email_id" class="mb-0 mt-2">Email Id</label>
                    <input type="text" class="form-control" id="customer_email_id" name="customer_email_id">
                </div>
                <div class="form-group col-md-4 col-lg-4 col-sm-12">
                    <label for="sales_person_name" class="mb-0 mt-2">Salesperson Name</label>
                    <input type="text" class="form-control" id="sales_person_name" name="sales_person_name">
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="pickup_address" class="mb-0 mt-2">Routes*</label>
                    <input type="text" class="form-control" id="pickup_address" name="pickup_address" required>
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="delivery_address" class="mb-0 mt-2">&nbsp;</label>
                    <input type="text" class="form-control" id="delivery_address" name="delivery_address" required>
                </div>
                <div class="form-group col-md-6 col-lg-6 col-sm-12">
                    <label for="d_business_name" class="mb-0 mt-2">Trailer Type</label>
                    <div class="input-group">
                        <input type="radio" groupname="tt" id="tt_open" checked class="mr-2"><label for="tt_open" class="mr-5 mt-1">Open</label>
                        <input type="radio" groupname="tt" id="tt_enclosed" class="mr-2"><label for="tt_enclosed" class="mt-1">Enclosed</label>
                    </div>
                </div>
                <div class="form-group col-md-12 col-lg-12 col-sm-12">
                    <label for="" class="mb-0 mt-2">Vehicle Information</label>
                    <div id="vehicle_block" class="col-md-12  offset-md-12 row">

                    </div>
                </div>

                <div class="form-group mt-5 col-md-12 col-lg-12 col-sm-12 text-right mt-0 ">
                    <a class="form-group btn-secondary rounded pl-5 pr-5 pt-2 pb-2 font-weight-bold">Clear</a>
                    <button type="submit" class="form-group btn-success pl-5 pr-5 pt-2 pb-2 rounded font-weight-bold">Save</button>
                </div>

        </form>

    </div>
</div>
@endsection
@section('jsScript')
<script>
    var i = 0;
    jQuery(document).ready(function() {
        /* On page load add  first vehicle row*/
        addVehicle();

         /* Form Submit with validation check */
         $("#getQuotation").submit(function(e) {
            e.preventDefault();
        }).validate({
            rules: {
                pickup_address: {
                    required: true,
                },
                delivery_address:{
                    required:true,
                }
            },
            submitHandler: function(form) {
                $('.loading').show();
                $.ajax({
                    url: '{{route("getQuotation")}}',
                    method: 'POST',
                    data: $(form).serialize(),
                    success: function(response) {
                        if (response && response.status) {
                            toastr.success(response.quote_value);
                            $('.loading').hide();
                        } else {
                            console.error("Property 'mode' is undefined in the response.");
                            $('.loading').hide();
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX request failed:", status, error);
                    }
                });
            },
        })
    });

    function addVehicle() {
        var vehicleLength = jQuery('.vehicle-row-exist').length;
        if (vehicleLength > 4) {
            toastr.error('You can not add more than 5 vehicle');
            return false;
        }
        i = vehicleLength + 1;
        $('.add-btn').addClass('d-none');
        var html = '';
        html += '<div class="row vehicleRow' + i + ' vehicle-row-exist">';
        html += '<div class="form-group col-md-2 col-lg-2 col-sm-12">';
        html += '    <label for="year' + i + '" class="mb-0 mt-2">Year</label>';
        html += '    <input type="text" class="form-control" id="year' + i + '" name="year' + i + '" required>';
        html += '</div>';
        html += '<div class="form-group col-md-2 col-lg-2 col-sm-12">';
        html += '    <label for="make' + i + '" class="mb-0 mt-2">Make*</label>';
        html += '    <input type="text" class="form-control" id="make' + i + '" name="make' + i + '" required>';
        html += '</div>';
        html += '<div class="form-group col-md-2 col-lg-2 col-sm-12">';
        html += '    <label for="model' + i + '" class="mb-0 mt-2">Model*</label>';
        html += '    <input type="text" class="form-control" id="model' + i + '" name="model' + i + '" required>';
        html += '</div>';
        html += '<div class="form-group col-md-2 col-lg-2 col-sm-12">';
        html += '    <label for="type' + i + '" class="mb-0 mt-2">Type</label>';
        html += '    <select type="text" class="form-control" id="type' + i + '" name="type' + i + '" required>';
        html += '           <option value="sedan">Sedan</option>';
        html += '           <option value="2_door_coupe">Coupe (2 Door)</option>';
        html += '           <option value="suv">SUV</option>';
        html += '           <option value="pickup">Pickup (2 Door)</option>';
        html += '           <option value="4_door_pickup">Pickup (4 Door)</option>';
        html += '           <option value="van">Van</option>';
        html += '           <option value="truck_daycab">Truck (daycab)</option>';
        html += '           <option value="truck_sleeper">Truck (with sleeper)</option>';
        html += '           <option value="motorcycle">Motorcycle</option>';
        html += '           <option value="boat">Boat</option>';
        html += '           <option value="rv">RV</option>';
        html += '           <option value="heavy_machinery">Heavy Machinery</option>';
        html += '           <option value="freight">Freight</option>';
        html += '           <option value="livestock">Livestock</option>';
        html += '           <option value="atv">ATV</option>';
        html += '           <option value="trailer_bumper_pull">Trailer (Bumper Pull)</option>';
        html += '           <option value="trailer_gooseneck">Trailer (Gooseneck)</option>';
        html += '           <option value="trailer_5th_wheel">Trailer (5th Wheel)</option>';
        html += '           <option value="other">Other</option>';
        html += '    </select>';
        html += '</div>';
        html += '<div class="form-group col-md-1 col-lg-1 col-sm-12">';
        html += '    <label for="indp' + i + '" class="mb-0 mt-2 ml-3">INDP</label>';
        html += '    <input type="checkbox" class="form-control" id="indp' + i + '" name="indp' + i + '">';
        html += '</div>';
        html += '<div class="form-group col-md-2 col-lg-2 col-sm-12 text-left pt-4_5">';
        html += '    <a onClick="addVehicle()" class="form-group btn-success p-2 rounded add-btn add-vehicle-btn-' + i + '"><i class="fa fa-plus mr-2"></i> Vehicle</a>';
        html += '</div>';
        html += '</div>';

        jQuery('#vehicle_block').append(html);

    }

</script>
@stop