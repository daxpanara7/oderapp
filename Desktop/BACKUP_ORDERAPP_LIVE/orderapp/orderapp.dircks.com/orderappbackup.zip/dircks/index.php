<?php
echo  phpinfo();
?>