
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12  offset-md-12">
        <table id="myTable" class="display">
            <thead>
            <tr>
                    
                    <th>Pick-up</th>
                    <th>Delivery</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Sales Person</th>
                    <th>Type</th>
                    <th>value</th>
                    <th>Final Value</th>
                    <th>Year</th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>Type</th>
                    <th>Inoperable</th>
                    <th>Vehicle</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($item->pickup_address); ?></td>
                    <td><?php echo e($item->delivery_address); ?></td>
                    <td><?php echo e($item->customer_name); ?></td>
                    <td><?php echo e($item->customer_email_id); ?></td>
                    <td><?php echo e($item->sales_person_name); ?></td>
                    <td><?php echo e($item->quote_type); ?></td>
                    <td><?php echo e($item->quote_value); ?></td>
                    <td><?php echo e($item->final_value); ?></td>
                    <td><?php echo e($item->vehicle[0]->year); ?></td>
                    <td><?php echo e($item->vehicle[0]->make); ?></td>
                    <td><?php echo e($item->vehicle[0]->model); ?></td>
                    <td><?php echo e($item->vehicle[0]->type); ?></td>
                    <td><?php echo e(($item->vehicle[0]->is_inoperable) ?  'Yes' : 'No'); ?></td>
                    <td>
                        <a href="javascript:void(0)" class="popupClass" onClick="openPopup(this)"
                        data-html="
                        <?php if($item->vehicle): ?>
                            <?php $__currentLoopData = $item->vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <b>Vin </b> :<?php echo e(($vItem->vin) ? $vItem->vin : '-'); ?>  <br>
                            <b>Year </b> :<?php echo e(($vItem->year) ? $vItem->year : '-'); ?>  <br>
                            <b>Make </b> :<?php echo e(($vItem->make) ? $vItem->make : '-'); ?>  <br>
                            <b>Model </b> :<?php echo e(($vItem->model) ? $vItem->model : '-'); ?>  <br>
                            <b>Type </b> :<?php echo e(($vItem->type) ? $vItem->type : '-'); ?>  <br>
                            <b>Inoperable </b> :<?php echo e(($vItem->is_inoperable) ? 'Yes' : 'No'); ?>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            '-'
                        <?php endif; ?>
                        "
                        >View Details</a>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Vehicle Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsScript'); ?>
<script>
 //let table = new DataTable('#myTable');
 $(document).ready(function() {
        var table = $('#myTable').DataTable({
            scrollX: true,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'csvHtml5',
                    text: 'CSV',
                    filename: 'custom_data_export',
                    exportOptions: {
                        columns: [0, 1,2, 3, 4,5,6,7,8,9,10,11,12] // Remove the second column (index 1) from export
                    }
                }
            ],
        });
    });
 
 function openPopup(ele){
     var a =  $(ele).data('html')
     $('.modal-body').html(a)
     $('#exampleModal').modal('show')
 }
 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/dircks.com/orderapp.dircks.com/resources/views/quotation_list.blade.php ENDPATH**/ ?>