<footer class="mt-5 col-12 ">
    
</footer><?php /**PATH /var/www/vhosts/dircks.com/orderapp.dircks.com/resources/views/partials/footer.blade.php ENDPATH**/ ?>